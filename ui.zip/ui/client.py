# client.py
import requests

API_BASE = "http://localhost:8000"
AUTH_HEADER = {"Authorization": "Bearer supersecrettoken"}

def list_chats():
    try:
        r = requests.get(f"{API_BASE}/history/list", headers=AUTH_HEADER)
        return r.json().get("chat_ids", [])
    except:
        return []

def delete_chat(chat_id):
    try:
        return requests.delete(f"{API_BASE}/history/{chat_id}", headers=AUTH_HEADER)
    except:
        return None

def load_history(chat_id):
    try:
        r = requests.get(f"{API_BASE}/history/{chat_id}", headers=AUTH_HEADER)
        return r.json().get("history", [])
    except:
        return []

def stream_chat(query, chat_id):
    payload = {"chat_id": chat_id, "query": query}
    with requests.post(f"{API_BASE}/chat/stream", headers=AUTH_HEADER, json=payload, stream=True) as resp:
        for chunk in resp.iter_content(chunk_size=1, decode_unicode=True):
            if chunk:
                yield chunk
