import uuid
import streamlit as st
from client import stream_chat, list_chats, delete_chat, load_history

st.set_page_config(page_title="LLM DevOps · Chat", page_icon="💬")

# ─── State Init ───────────────────────────────────────────────
if "chat_id" not in st.session_state:
    st.session_state.chat_id = str(uuid.uuid4())
if "messages" not in st.session_state:
    st.session_state.messages = []

chat_id = st.session_state.chat_id

# ─── Sidebar ──────────────────────────────────────────────────
with st.sidebar:
    st.header("🧠 Chat Sessions")

    # Load all chats
    all_chats = list_chats()
    if chat_id not in all_chats:
        all_chats.append(chat_id)

    selected = st.selectbox(
        "🗂 Select chat",
        options=sorted(all_chats),
        index=sorted(all_chats).index(chat_id),
        key="session_selector"
    )

    # Switch chat session
    if selected != chat_id:
        st.session_state.chat_id = selected
        st.session_state.messages = load_history(selected)
        st.rerun()

    if st.button("➕ New Chat"):
        new_id = str(uuid.uuid4())
        st.session_state.chat_id = new_id
        st.session_state.messages = []
        st.rerun()

    if st.button("🗑 Delete This Chat"):
        delete_chat(chat_id)
        st.session_state.chat_id = str(uuid.uuid4())
        st.session_state.messages = []
        st.rerun()

    st.selectbox("🧠 Model", ["openai-gpt-4o", "openai-gpt-4o-mini"], key="model")

# ─── Load history (if not yet loaded) ─────────────────────────
if not st.session_state.messages:
    st.session_state.messages = load_history(chat_id)

# ─── Chat UI ──────────────────────────────────────────────────
chat_box = st.container()
for msg in st.session_state.messages:
    with chat_box.chat_message(msg["role"]):
        st.markdown(msg["content"])

# ─── Input box ────────────────────────────────────────────────
prompt = st.chat_input("Ask me anything…1")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with chat_box.chat_message("user"):
        st.markdown(prompt)

    with chat_box.chat_message("assistant"):
        full_response = ""
        block = st.empty()
        try:
            for token in stream_chat(prompt, chat_id):
                full_response += token
                block.markdown(full_response + "▌")
        except Exception as e:
            full_response = f"❌ {e}"
        block.markdown(full_response)

    st.session_state.messages.append({"role": "assistant", "content": full_response})
